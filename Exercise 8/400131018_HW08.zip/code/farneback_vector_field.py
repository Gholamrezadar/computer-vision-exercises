import numpy as np
import cv2

def hsv2bgr(a):
    a_hsv = np.uint8([[a]]) # Single pixel image
    a_bgr = cv2.cvtColor(a_hsv, cv2.COLOR_HSV2BGR) 
    return a_bgr[0][0].tolist() # Return the single pixel

cap = cv2.VideoCapture("rubik.mp4")
FPS = cap.get(cv2.CAP_PROP_FPS)
SIZE = (int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)))
FRAME_COUNT = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

out = cv2.VideoWriter('output_Farneback_vf_rubik_3.mp4', cv2.VideoWriter_fourcc(*'mp4v'), FPS, SIZE)

ret, frame1 = cap.read()
prvs = cv2.cvtColor(frame1, cv2.COLOR_BGR2GRAY)
# hsv = np.zeros_like(frame1)
# Saturation is 100%
# hsv[..., 1] = 255

frame_number = 0
while(1):
    # Read the next frame
    ret, frame2 = cap.read()
    if not ret:
        print('No frames grabbed!')
        break
    # Progress
    print('{:.2f}% | Frame: {}/{}'.format(frame_number/FRAME_COUNT*100,frame_number, FRAME_COUNT))

    
    # Create a mask image for drawing purposes
    mask = np.zeros_like(frame2)

    # Calculate the optical flow using Farneback's method
    next = cv2.cvtColor(frame2, cv2.COLOR_BGR2GRAY)
    flow = cv2.calcOpticalFlowFarneback(prvs, next, None, 0.5, 3, 15, 3, 5, 1.2, 0)
    # import pdb; pdb.set_trace()

    # Calculate the magnitude and angle of the motion vectors
    mag, ang = cv2.cartToPolar(flow[..., 0], flow[..., 1])

    # draw arrows on the mask image
    l = 2.5 # Length multiplier
    for i in range(0, mask.shape[0], 16):
        for j in range(0, mask.shape[1], 16):
            # color based on angle
            color = (int(ang[i, j]*180/np.pi/2), 255, 255)
            color = hsv2bgr(color)
            # import pdb; pdb.set_trace()
            cv2.arrowedLine(mask, (int(j - l*flow[i, j, 0]), int(i - l*flow[i, j, 1])), (j, i), color, 2)

    # combine the mask and the frame
    frame2 = cv2.add(frame2, mask)
    # Show the frame and write it to the output file
    cv2.imshow('frame2', frame2)
    out.write(frame2)

    # press ESC to exit
    k = cv2.waitKey(1) & 0xff
    if k == 27:
        break

    # Set the previous frame to the current frame
    prvs = next
    frame_number += 1

cv2.destroyAllWindows()