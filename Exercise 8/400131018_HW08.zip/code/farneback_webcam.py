import numpy as np
import cv2

cap = cv2.VideoCapture(0)
# FPS = cap.get(cv2.CAP_PROP_FPS)
# SIZE = (int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)))
# FRAME_COUNT = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

# out = cv2.VideoWriter('output_Farneback_traffic.mp4', cv2.VideoWriter_fourcc(*'mp4v'), FPS, SIZE)

ret, frame1 = cap.read()
prvs = cv2.cvtColor(frame1, cv2.COLOR_BGR2GRAY)
hsv = np.zeros_like(frame1)
# Saturation is 100%
hsv[..., 1] = 255

frame_number = 0
while(1):
    # Read the next frame
    ret, frame2 = cap.read()
    if not ret:
        print('No frames grabbed!')
        break
    # Progress
    # print('{:.2f}% | Frame: {}/{}'.format(frame_number/FRAME_COUNT*100,frame_number, FRAME_COUNT))

    # Calculate the optical flow using Farneback's method
    next = cv2.cvtColor(frame2, cv2.COLOR_BGR2GRAY)
    flow = cv2.calcOpticalFlowFarneback(prvs, next, None, 0.5, 3, 15, 3, 5, 1.2, 0)

    # Calculate the magnitude and angle of the motion vectors
    mag, ang = cv2.cartToPolar(flow[..., 0], flow[..., 1])
    # Angle is hue
    hsv[..., 0] = ang*180/np.pi/2
    # Magnitude is value
    hsv[..., 2] = cv2.normalize(mag, None, 0, 255, cv2.NORM_MINMAX)
    # Convert HSV to BGR
    bgr = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)

    # Show the frame and write it to the output file
    cv2.imshow('frame2', bgr)
    # out.write(bgr)

    # press ESC to exit
    k = cv2.waitKey(30) & 0xff
    if k == 27:
        break

    # Set the previous frame to the current frame
    prvs = next
    frame_number += 1

cv2.destroyAllWindows()