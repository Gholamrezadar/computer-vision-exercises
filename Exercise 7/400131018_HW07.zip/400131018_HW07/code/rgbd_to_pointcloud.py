import open3d as o3d
import numpy as np
import cv2

def conv_rgb(img):
    return img[:, :, ::-1]

def img_to_pointcloud(img, depth):
    rgb = o3d.geometry.Image(img)
    depth = o3d.geometry.Image(depth)
    rgbd = o3d.geometry.RGBDImage.create_from_color_and_depth(rgb, depth, convert_rgb_to_intensity=False)
    pc = o3d.geometry.PointCloud.create_from_rgbd_image(rgbd, o3d.camera.PinholeCameraIntrinsic(
        o3d.camera.PinholeCameraIntrinsicParameters.PrimeSenseDefault))
    pc.transform([[1, 0, 0, 0], [0, -1, 0, 0], [0, 0, -1, 0], [0, 0, 0, 1]])
    o3d.visualization.draw_geometries([pc])

if __name__ == '__main__':
    print(o3d.__version__)
    img = o3d.io.read_image('color.png')
    depth = o3d.io.read_image('depth.png')
    img_to_pointcloud(img, depth)